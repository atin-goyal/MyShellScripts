export ORACLE_HOME=/scratch/perfgrp/oracle/product/11.2.0/client_1
export PATH=/scratch/perfgrp/oracle/product/11.2.0/client_1/bin:$PATH
/scratch/perfgrp/oracle/product/11.2.0/client_1/bin/sqlldr userid=PPM/welcome1@slc02pww:1521/orcl.us.oracle.com CONTROL=pod_resource_metrics.ctl  skip=1
