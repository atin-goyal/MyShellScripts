#!/bin/bash
start_date=`date -d "1 days ago" "+%d-%b-%y"` 
end_date=`date  "+%d-%b-%y"`
echo "getting data for pods in pod_names.txt from cloued em from $start_date to $end_date"
rm error.log
./PodMetricsAnalyzer.sh $start_date $end_date |tee pma_$end_date.log
cat error.log >> pma_$end_date.log 

if [ $? -ne 0 ]
then
echo "something went wrong. Check pma log"
exit
fi

echo "inserting the data in DB"

./insert_to_db.sh 
cat pod_resource_metrics.log > sqlldr_$end_date.log

if [ $? -ne 0 ]
then
echo "something went wrong. Check sqlldr log"
exit
fi

exit
