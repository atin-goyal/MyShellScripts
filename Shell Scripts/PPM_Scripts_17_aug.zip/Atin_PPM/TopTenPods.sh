#/bin/bash
set -x

if [ $# -eq 0 ]
then
echo "Usage of the script: ./TopTenPods.sh <no of days to get data for>"
exit
fi

no_of_days=$1

echo "getting graphite Idle CPU data for all pods for $no_of_days days"
#curl 'https://graphite.usdc2.oraclecloud.com/render/?tz=UTC&target=paas.bdp.bdp-ms.*.*.*.cpu.total.idle&format=raw&from=-'$no_of_days'd' > data.csv
curl 'https://graphite.usdc2.oraclecloud.com/render/?tz=UTC&target=paas.bi.pod.*.*.*.cpu.total.idle&format=raw&from=-'$no_of_days'd' > data.csv
if [ $? -ne 0 ]
then
echo "curl command failed"
exit
fi

if [ `grep -c "<title>404 Not Found</title>" data.csv` -gt 0 ]
then
echo "curl command failed"
exit
fi

sed 's/None/800/g' data.csv >1.tmp
awk 'BEGIN{FS=",";} {s=0; for (i=5; i<=NF; i++) s=s+$i;print $1,100-(s/(NF-4))/8}' 1.tmp > 2.tmp

for pod in `cat ignore_pods.txt`
do
	echo "Ignoring $pod"
	grep -v $pod 2.tmp > 5.tmp
done

mv 5.tmp 2.tmp

sort -nrk2 2.tmp | head > 3.tmp
echo "Pod name","CPU Utilization (%)" > 4.tmp
paste <(awk -F ',' '{print $1}' 3.tmp |awk -F'.' '{print $6}'|tr '_' '.') <(awk '{print ","$2}' 3.tmp)>>4.tmp
sed 's/	,/,/g' 4.tmp > output.txt
cat output.txt
rm *.tmp
exit