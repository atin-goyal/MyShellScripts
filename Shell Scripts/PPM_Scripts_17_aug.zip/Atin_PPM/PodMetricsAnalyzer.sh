#/bin/bash
#set -x

if [ $# -eq 2 ]
then
start_date=`date -d "$1"  "+%d-%b-%y"`
if [ $? -ne 0 ]
then
echo "Start date must be in DD-MON-YY format like 07-Jul-16"
exit
fi

end_date=`date -d "$2" "+%d-%b-%y"`
if [ $? -ne 0 ]
then
echo "End date must be in DD-MON-YY format like 07-Jul-16"
exit
fi

start_epoch=`date -d "$1" "+%s"`
end_epoch=`date -d "$2" "+%s"`
if (( start_epoch > end_epoch ))
then
echo "End date must be greater than start date"
exit
fi

else
echo "Usage of the script: ./PodMetricsAnalyzer.sh <start date in DD-MON-YY> <end date in DD-MON-YY>. e.g. ./PodMetricsAnalyzer.sh 07-Jul-16 09-Jul-16. It will get various stats for pods in metrics.csv for the duration"
exit
fi

echo "POD Key,Week_End_date,Average CPU Utilization (%),Min CPU Utilization (%),Max CPU Utilization (%),90th Percentile CPU Utilization (%),Average Memory Utilization (%),Min Memory Utilization (%),Max Memory Utilization (%),90th Percentile Memory Utilization (%),Average All Network Interfaces Total I/O Rate (MB/sec),Min All Network Interfaces Total I/O Rate (MB/sec),Max All Network Interfaces Total I/O Rate (MB/sec),90th Percentile All Network Interfaces Total I/O Rate (MB/sec), Max All Network Interfaces Combined Utilization (%),Average Total Disk I/O made across all disks (per second),Min Total Disk I/O made across all disks (per second),Max Total Disk I/O made across all disks (per second),90th Percentile Total Disk I/O made across all disks (per second),Max Disk I/O (per sec) made by a single disk,Max Total Disk Utilized (%) (across all local filesystems)" > final_metrics.out


if [ ! -e pod_names.txt ]
then
echo "pod_names.txt file not found"
exit
fi

for pod in `awk -F ',' 'NR>=2 {print $1}' pod_names.txt`
do
		echo "Getting data for $pod from cloudem"
		#curl 'https://graphite.usdc2.oraclecloud.com/render/?tz=UTC&target='$pod'.cpu.total.user&target='$pod'.cpu.total.idle&target='$pod'.cpu.total.iowait&target='$pod'.cpu.total.system&target='$pod'.cpu.total.nice&format=raw&from=-'$no_of_days'd' > $pod.csv
		wget "https://cloudemtools.us1.oraclecloud.com/ords/cloudem/PaaSHostMetricDetails/$pod:$start_date 00:$end_date 00" -O $pod.csv 2> 1.tmp
		if [ $? -ne 0 ]
		then
		echo "wget command failed for $pod"
		rm $pod.csv
		fi

		if [ -e $pod.csv ]
		then
			if [ `grep -c "awaiting response... 200 OK" 1.tmp` -lt 1 ] || [ `grep -c $pod $pod.csv` -lt 1 ]
			then
			echo "wget command failed for $pod"
			echo "Curl command output" >> error.log
			cat 1.tmp >> error.log
			echo "output csv" >> error.log
			cat $pod.csv >> error.log
			rm $pod.csv			
			continue
			fi
			
			#Calculate CPU
			if [ `grep -c "CPU Utilization (%)" $pod.csv` -ge 1 ]
			then
			min_cpu=`grep "CPU Utilization (%)" $pod.csv |  awk -F ',' -v min=200.00 '{if($5<min && $5 -ne ''){min=$5}}END{print min}'`
			max_cpu=`grep "CPU Utilization (%)" $pod.csv |  awk -F ',' -v max=0.00 '{if($6>max && $6 -ne ''){max=$6}}END{print max}'`
			avg_cpu=`grep "CPU Utilization (%)" $pod.csv |  awk 'BEGIN{FS=",";}{ sum += $7 } END { if (NR > 0) print sum / NR }'`
			ninety_percentile_cpu=`grep "CPU Utilization (%)" $pod.csv | awk -F "," '{print $6}' | sort -n | awk '{s[NR-1]=$1} END{print s[int(NR*0.90-0.5)]}'`
			fi
			
			#Calculate Mem
			if [ `grep -c "Memory Utilization (%)" $pod.csv` -ge 1 ]
			then			
			min_mem=`grep "Memory Utilization (%)" $pod.csv |  awk -F ',' -v min=200.00 '{if($5<min && $5 -ne ''){min=$5}}END{print min}'`
			max_mem=`grep "Memory Utilization (%)" $pod.csv |  awk -F ',' -v max=0.00 '{if($6>max && $6 -ne ''){max=$6}}END{print max}'`
			avg_mem=`grep "Memory Utilization (%)" $pod.csv |  awk 'BEGIN{FS=",";}{ sum += $7 } END { if (NR > 0) print sum / NR }'`
			ninety_percentile_mem=`grep "Memory Utilization (%)" $pod.csv | awk -F "," '{print $6}' | sort -n | awk '{s[NR-1]=$1} END{print s[int(NR*0.90-0.5)]}'`
			fi
			
			#Calculate NW
			if [ `grep -c "All Network Interfaces Total I/O Rate (MB/sec)" $pod.csv` -ge 1 ]
			then			
			min_nw=`grep "All Network Interfaces Total I/O Rate (MB/sec)" $pod.csv |  awk -F ',' -v min=200.00 '{if($5<min && $5 -ne ''){min=$5}}END{print min}'`
			max_nw=`grep "All Network Interfaces Total I/O Rate (MB/sec)" $pod.csv |  awk -F ',' -v max=0.00 '{if($6>max && $6 -ne ''){max=$6}}END{print max}'`
			avg_nw=`grep "All Network Interfaces Total I/O Rate (MB/sec)" $pod.csv |  awk 'BEGIN{FS=",";}{ sum += $7 } END { if (NR > 0) print sum / NR }'`
			ninety_percentile_nw=`grep "All Network Interfaces Total I/O Rate (MB/sec)" $pod.csv | awk -F "," '{print $6}' | sort -n | awk '{s[NR-1]=$1} END{print s[int(NR*0.90-0.5)]}'`
			fi
			
			if [ `grep -c "All Network Interfaces Combined Utilization (%)" $pod.csv` -ge 1 ]
			then			
			max_total_nw=`grep "All Network Interfaces Combined Utilization (%)" $pod.csv |  awk -F ',' -v max=0.00 '{if($6>max && $6 -ne ''){max=$6}}END{print max}'`
			fi
			
			#Calculate Disk
			if [ `grep -c "Total Disk I/O made across all disks (per second)" $pod.csv` -ge 1 ]
			then			
			min_total_disk=`grep "Total Disk I/O made across all disks (per second)" $pod.csv |  awk -F ',' -v min=200.00 '{if($5<min && $5 -ne ''){min=$5}}END{print min}'`
			max_total_disk=`grep "Total Disk I/O made across all disks (per second)" $pod.csv |  awk -F ',' -v max=0.00 '{if($6>max && $6 -ne ''){max=$6}}END{print max}'`
			avg_total_disk=`grep "Total Disk I/O made across all disks (per second)" $pod.csv |  awk 'BEGIN{FS=",";}{ sum += $7 } END { if (NR > 0) print sum / NR }'`
			ninety_percentile_total_disk=`grep "Total Disk I/O made across all disks (per second)" $pod.csv | awk -F "," '{print $6}' | sort -n | awk '{s[NR-1]=$1} END{print s[int(NR*0.90-0.5)]}'`

			fi
			
			if [ `grep -c "Max Disk I/O (per sec) made by a single disk" $pod.csv` -ge 1 ]
			then	
			max_disk_io=`grep "Max Disk I/O (per sec) made by a single disk" $pod.csv |  awk -F ',' -v max=0.00 '{if($6>max && $6 -ne ''){max=$6}}END{print max}'`
			fi
			
			if [ `grep -c "Total Disk Utilized (%) (across all local filesystems)" $pod.csv` -ge 1 ]
			then	
			max_disk_space_utilization=`grep "Total Disk Utilized (%) (across all local filesystems)" $pod.csv |  awk -F ',' -v max=0.00 '{if($6>max && $6 -ne ''){max=$6}}END{print max}'`
			fi
			
			echo "`echo $pod |cut -d '-' -f3,4 | cut -d '.' -f1 | tr '[:lower:]' '[:upper:]'`,$start_date,$avg_cpu,$min_cpu,$max_cpu,$ninety_percentile_cpu,$avg_mem,$min_mem,$max_mem,$ninety_percentile_mem,$avg_nw,$min_nw,$max_nw,$ninety_percentile_nw,$max_total_nw,$avg_total_disk,$min_total_disk,$max_total_disk,$ninety_percentile_total_disk,$max_disk_io,$max_disk_space_utilization" >> final_metrics.out
		
		fi
done

rm *.tmp
mkdir -p archive/$end_date
mv *.csv archive/$end_date

mv final_metrics.out final_metrics.csv
cp final_metrics.csv archive/$end_date
exit
