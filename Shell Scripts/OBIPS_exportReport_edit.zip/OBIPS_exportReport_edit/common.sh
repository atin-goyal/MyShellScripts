#!/bin/bash

export U01APP=/scratch/perfgrp/u01/app 
export ORACLE_HOME=$U01APP/fmw/Oracle_BI1
export USER_PROJECT=${U01APP}/fmw/user_projects
export CATALOGMGR_DIR=${U01APP}/instances/instance1/bifoundation/OracleBIPresentationServicesComponent/coreapplication_obips1/catalogmanager
export WEBCAT=$U01APP/BIShared/shared/catalog

