#!/bin/bash

for (( tenant=1001; tenant <=1005; tenant++ ))
do
   for (( userid=71; userid <= 71; userid++ ))
   do
      echo importOBIPSReport.sh $tenant $userid
      ./importOBIPSReport.sh $tenant $userid
   done
done
