#!/bin/bash

for (( tenant=1001; tenant <=1005; tenant++ ))
do
   for (( userid=71; userid <= 71; userid++ ))
   do
      echo replaceUsernameInReport.sh $tenant $userid
      ./replaceUsernameInReport.sh  $userid $tenant
   done
done
