#!/bin/bash
if [ -z "$1" ]; then
   echo ERROR uid need
   exit
fi
ID="$2"
export TENANTID="$1"
export USERID="psr${TENANTID}biconsumeruser${ID}"
export FULLUSERID="${TENANTID}.service1.${USERID}"
export impUserFolder="/tenants/${TENANTID}.service1/users/${FULLUSERID}"
export SERVICE="1"
export reportname1="psr1"
export reportname2="psr2"
export reportname3="psr3"
set -vx
. ./common.sh
cd ${CATALOGMGR_DIR}
export report1=/tenants/${TENANTID}.service1/users/${FULLUSERID}/PSR1
export report2=/tenants/${TENANTID}.service1/users/${FULLUSERID}/PSR2
export report3=/tenants/${TENANTID}.service1/users/${FULLUSERID}/PSR3

./runcat.sh -cmd createFolder -offline ${WEBCAT} -folder ${impUserFolder}
./runcat.sh -cmd unarchive -offline ${WEBCAT}  -inputFile /tmp/PSR_Mashup.catalog -folder ${impUserFolder}

TENANTSDIR=${WEBCAT}/root/tenants
USERDIR=${TENANTSDIR}/${TENANTID}%2eservice${SERVICE}/users/${TENANTID}%2eservice${SERVICE}%2e${USERID}
RPTDIR1=${USERDIR}/${reportname1}
sed -i s/psr1001admin@psr1001.com/${USERID}/g ${RPTDIR1}/_projectdefn
RPTDIR2=${USERDIR}/${reportname2}
sed -i s/psr1001admin@psr1001.com/${USERID}/g ${RPTDIR2}/_projectdefn
RPTDIR3=${USERDIR}/${reportname3}
sed -i s/psr1001admin@psr1001.com/${USERID}/g ${RPTDIR3}/_projectdefn
set +xv

