#!/bin/bash
set -v
. ./common.sh
#${CATALOGMGR_DIR}/runcat.sh -cmd archive -offline ${WEBCAT} -inputFile ~/archivedReport/mashupreport_1000M_PSR1.catalog  -folder /users/rpd_empl14
cd ${CATALOGMGR_DIR}
#./runcat.sh -cmd archive -offline ${WEBCAT} -outputFile /tmp/psrStoryTelling50snapshots.catalog -folder /users/1001.service1.psr1001admin@psr1001.com/PSR-StoryTelling-50snapshots:/users/1001.service1.psr1001admin@psr1001.com/PSR-StoryTelling-6snapshots 

export report1=/tenants/1001.service1/users/1001.service1.psr1001admin@psr1001.com/two-xsa-xsa--1mrows-lessdim
#export report1=/tenants/1001.service1/users/1001.service1.psr1001admin@psr1001.com/PSR1
#export report2=/tenants/1001.service1/users/1001.service1.psr1001admin@psr1001.com/PSR2
#export report3=/tenants/1001.service1/users/1001.service1.psr1001admin@psr1001.com/PSR3
./runcat.sh -cmd archive -offline ${WEBCAT} -outputFile /tmp/PSR_Mashup.catalog -folder ${report1}:${report2}
set +v

