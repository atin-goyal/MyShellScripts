#!/bin/bash
#set -x
. autodetect_shape.sh 
. audit.properties
. validate_RPD.sh
. validate_OBIS.sh
. validate_HeapSize.sh 
. validate_OBIPS.sh
exit
