#!/bin/bash
#set -x
#exec 2>/dev/null

if [ ! -e instanceconfig.xml ]
then
        echo "ERROR: instanceconfig.xml not found."
        exit
fi

tmp=`sed -n '/<Pivot/,/<\/Pivot>/p' instanceconfig.xml | sed -n '/<DefaultRowsDisplayedInDownload/,/<\/DefaultRowsDisplayedInDownload>/p' | sed 's/^ *//'| grep DefaultRowsDisplayedInDownload | awk -F'>|<' '{print $3}'`
if [ $tmp -ne $OBIPS_PIVOT_DEFAULTROWSDISPLAYEDINDOWNLOAD ]
then
echo "MISMATCH:OBIPS_PIVOT_DEFAULTROWSDISPLAYEDINDOWNLOAD is set to $tmp. It should be set to $OBIPS_PIVOT_DEFAULTROWSDISPLAYEDINDOWNLOAD"
else
echo "MATCH:OBIPS_PIVOT_DEFAULTROWSDISPLAYEDINDOWNLOAD is correctly set to $tmp"
fi

tmp=`sed -n '/<Table/,/<\/Table>/p' instanceconfig.xml | sed -n '/<DefaultRowsDisplayedInDownload/,/<\/DefaultRowsDisplayedInDownload>/p' | sed 's/^ *//'| grep DefaultRowsDisplayedInDownload | awk -F'>|<' '{print $3}'`
if [ $tmp -ne $OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOAD ]
then
echo "MISMATCH:OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOAD is set to $tmp. It should be set to $OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOAD"
else
echo "MATCH:OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOAD is correctly set to $tmp"
fi

tmp=`sed -n '/<Table/,/<\/Table>/p' instanceconfig.xml | sed -n '/<DefaultRowsDisplayedInDownloadCSV/,/<\/DefaultRowsDisplayedInDownloadCSV>/p' | sed 's/^ *//'| grep DefaultRowsDisplayedInDownloadCSV | awk -F'>|<' '{print $3}'`
if [ $tmp -ne $OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOADCSV ]
then
echo "MISMATCH:OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOADCSV is set to $tmp. It should be set to $OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOADCSV"
else
echo "MATCH:OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOADCSV is correctly set to $tmp"
fi

tmp=`sed -n '/<ResultRowLimit/,/<\/ResultRowLimit>/p' instanceconfig.xml | sed 's/^ *//'| grep ResultRowLimit | awk -F'>|<' '{print $3}'`
if [ $tmp -ne $OBIPS_RESULTROWLIMIT ]
then
echo "MISMATCH:OBIPS_RESULTROWLIMIT is set to $tmp. It should be set to $OBIPS_RESULTROWLIMIT"
else
echo "MATCH:OBIPS_RESULTROWLIMIT is correctly set to $tmp"
fi
