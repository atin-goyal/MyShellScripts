Date: Feb 8, 2017.
Contact: PSR_BI_SWAT_WW@ORACLE.COM.
Run using "./audit.sh | tee results.txt"

check https://confluence.oraclecorp.com/confluence/display/PSR/BICS+12c+Auto-Scale for list of parameters validated by this script
	
-- Sample output: --
$ ./audit.sh 
ascspod13-bi-1.compute-bicspsr.oraclecloud.internal pod's shape is oc3m
RPD download completed successfully.
UDML transaction has been successfully executed.
MISMATCH:  "DUMMY"."DUMMY_CP" Max Connection:  10 -is not as per standard. It
should be Set to 200
MATCH:OBIS_MAX_SESSION_LIMIT is correctly set to 5000
MATCH:OBIS_SERVER_THREAD_RANGE is correctly set to 40-100
MATCH:OBIS_DB_GATEWAY_THREAD_RANGE is correctly set to 40-200
MATCH:OBIS_HTTP_CLIENT_THREAD_RANGE is correctly set to 0-100
MISMATCH:OBIS_XSA_MAX_TOTAL_SPACE is set to 83000MB. It should be set to 100GB
MATCH:OBIS_XSA_CACHE_SEED_THREAD_RANGE is correctly set to 0-80
MATCH:JH_MAX_HEAP_SIZE is correctly set to 2048m
MATCH:BI_SERVER1_MAX_HEAP_SIZE is correctly set to 6144m
MATCH:BI_SERVER1_MIN_HEAP_SIZE is correctly set to 2048m
MATCH:OBIPS_PIVOT_DEFAULTROWSDISPLAYEDINDOWNLOAD is correctly set to 20000
MISMATCH:OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOAD is set to 65000. It should
be set to 20000
MATCH:OBIPS_TABLE_DEFAULTROWSDISPLAYEDINDOWNLOADCSV is correctly set to 65000
MATCH:OBIPS_RESULTROWLIMIT is correctly set to 65000
