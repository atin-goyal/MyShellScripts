#!/bin/bash
#set -x
#exec 2>/dev/null

free_space=`df .|tail -1|awk '{print $3}'`
if [ $free_space -lt "2097152" ]
then 
		echo "Free space is less than 2GB. Please free up some space and reun"
		exit
fi

$BITOOLS_BIN_PATH/datamodel.sh downloadrpd  -O repository.rpd -W welcome1 -SI $BI_SERVICE_INSTANCE_NAME -U $BI_ADMIN_USERNAME -P $BI_ADMIN_PASSWORD -Y

if [ ! -e repository.rpd ]
then
        echo "ERROR: RPD not found."
        exit
fi

###############To Check Max TimeOut#############################
Max_TimeOut()
{
		attribute="$1"
		if [ "$2" != '' ] && [ $2 -eq $TIME_OUT ]
                then
			echo "MATCH: " $1 "Time out: " $2 "- is as per standard"
                #elif [ "$timeOut_value" == '' ]
                #then
			#echo "MISMATCH: " $1 "Time out: NULL" "- is not as per standard. It should be Set to" $TIME_OUT
                else
			 echo "MISMATCH: " $1 "Time out:" $2 "- is not as per standard. It should be Set to" $TIME_OUT
                fi

}

############# To Check Max Connection ########################
Max_Conn()
{
MAX_CONNECTION="$3"
#		 attribute1=`echo $1 | awk -F'"' '{print $2}'`
		attribute1="$1"
                if [ "$2" != '' ] && [ $2 -eq $MAX_CONNECTION ]
                then
			echo "MATCH: " $1 "Max Connection: " $2 "- is as per standard"
                #elif [ "$max_connection_value" == '' ]
                #then
			#echo "MISMATCH: " $1 "Max Connection: NULL" "- is not as per standard. It should be Set to" $MAX_CONNECTION
                else
			echo "MISMATCH: " $1 "Max Connection: " $2 "-is not as per standard. It should be Set to" $MAX_CONNECTION
                fi
}


#########################################################################################
#echo $NQS_PATH
${BITOOLS_BIN_PATH}/nqudmlgen.sh -P welcome1 -R repository.rpd -O ./rpd.xml
if [ "$?" -eq 0 ]
then

	sed -n '/^DECLARE DATABASE/,/READ);/p' rpd.xml >for_datasources_tmp.txt
	grep "DECLARE DATABASE" for_datasources_tmp.txt | awk -F'"' '{print $2 }' > rpd_datasource.txt
	sed -n '/^DECLARE CONNECTION POOL/,/READ);/p' rpd.xml >tmp.txt
	grep "DECLARE CONNECTION POOL" tmp.txt | grep -oP '(?<=DECLARE CONNECTION POOL ).*?(?= AS \")' > connpool.txt
	
	while read i
	do
#		timeOut_value=`grep -w -A 3 "DECLARE CONNECTION POOL $i" tmp.txt|grep  "TIME OUT" | awk '{print $3}'`
#		Max_TimeOut "$i" "$timeOut_value"
		max_connection_value=`grep -w -A 5 "DECLARE CONNECTION POOL $i" tmp.txt|grep  "MAX CONNECTION" | awk '{print $3}'`
		Max_Conn "$i" "$max_connection_value" "$RPD_MAX_CONNECTION"

	 done < connpool.txt

############# Log Level Check ##################
#        log_level=`grep "LOGLEVEL" rpd.xml | grep "DECLARE RP VARIABLE" |sed -e "s/.*EXPRESSION {//;s/}//"`
#        if [ -z "$log_level" ]
#        then
#		echo  "MISMATCH: RPD Log Level: " "NOT DEFINED" "- is not as per standard. It should be:"  $RPD_LOG_LEVEL
#        else
#                if [ $log_level -eq $RPD_LOG_LEVEL ]
#                then
#			echo  "MATCH: RPD Log Level: " $log_level "- is as per standard"
#                else
#			echo  "MISMATCH: RPD Log Level: " $log_level "- is not as per standard. It should be:"  $RPD_LOG_LEVEL
#                fi
#        fi
else
        echo "Either Environment Variable is not properly set or RPD Password is wrong. Kindly Check"
fi
