#!/bin/bash
#set -x
#exec 2>/dev/null
if [ ! -e NQSConfig.INI ]
then
        echo "ERROR: NQSConfig.INI not found."
        exit
fi

tmp=`grep "MAX_SESSION_LIMIT" NQSConfig.INI | cut -d'=' -f2 | sed 's/ \|;//g'`
if [ $tmp -ne $OBIS_MAX_SESSION_LIMIT ]
then
echo "MISMATCH:OBIS_MAX_SESSION_LIMIT is set to $tmp. It should be set to $OBIS_MAX_SESSION_LIMIT"
else
echo "MATCH:OBIS_MAX_SESSION_LIMIT is correctly set to $tmp"
fi

tmp=`grep "SERVER_THREAD_RANGE" NQSConfig.INI | cut -d'=' -f2 | sed 's/ \|;//g'`
if [ $tmp != $OBIS_SERVER_THREAD_RANGE ]
then
echo "MISMATCH:OBIS_SERVER_THREAD_RANGE is set to $tmp. It should be set to $OBIS_SERVER_THREAD_RANGE"
else
echo "MATCH:OBIS_SERVER_THREAD_RANGE is correctly set to $tmp"
fi

tmp=`grep "DB_GATEWAY_THREAD_RANGE" NQSConfig.INI | cut -d'=' -f2 | sed 's/ \|;//g'`
if [ $tmp != $OBIS_DB_GATEWAY_THREAD_RANGE ]
then
echo "MISMATCH:OBIS_DB_GATEWAY_THREAD_RANGE is set to $tmp. It should be set to $OBIS_DB_GATEWAY_THREAD_RANGE"
else
echo "MATCH:OBIS_DB_GATEWAY_THREAD_RANGE is correctly set to $tmp"
fi

tmp=`grep "HTTP_CLIENT_THREAD_RANGE" NQSConfig.INI | cut -d'=' -f2 | sed 's/ \|;//g'`
if [ $tmp != $OBIS_HTTP_CLIENT_THREAD_RANGE ]
then
echo "MISMATCH:OBIS_HTTP_CLIENT_THREAD_RANGE is set to $tmp. It should be set to $OBIS_HTTP_CLIENT_THREAD_RANGE"
else
echo "MATCH:OBIS_HTTP_CLIENT_THREAD_RANGE is correctly set to $tmp"
fi

tmp=`grep "MAX_TOTAL_SPACE" NQSConfig.INI | cut -d'=' -f2 | sed 's/ \|;//g'`
if [ $tmp != $OBIS_XSA_MAX_TOTAL_SPACE ]
then
echo "MISMATCH:OBIS_XSA_MAX_TOTAL_SPACE is set to $tmp. It should be set to $OBIS_XSA_MAX_TOTAL_SPACE"
else
echo "MATCH:OBIS_XSA_MAX_TOTAL_SPACE is correctly set to $tmp"
fi

tmp=`grep "CACHE_SEED_THREAD_RANGE" NQSConfig.INI | cut -d'=' -f2 | sed 's/ \|;//g'`
if [ $tmp != $OBIS_XSA_CACHE_SEED_THREAD_RANGE ]
then
echo "MISMATCH:OBIS_XSA_CACHE_SEED_THREAD_RANGE is set to $tmp. It should be set to $OBIS_XSA_CACHE_SEED_THREAD_RANGE"
else
echo "MATCH:OBIS_XSA_CACHE_SEED_THREAD_RANGE is correctly set to $tmp"
fi

