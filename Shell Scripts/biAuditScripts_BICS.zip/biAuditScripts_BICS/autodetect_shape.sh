#set -x

core=`nproc --all`
memory=`free -m | grep Mem | awk -F' ' '{print $2}'`

#memory=$`(($memory)/1000)`

core=`echo "scale=0; ($core)/2" | bc -l`
memory=`echo "scale=0; ($memory)/1000" | bc -l`

if [ $core -eq 1 ] && [ $memory -eq 7 ]
then
	export POD_TYPE_FOR_AUDIT=oc3
else 
	if [ $core -eq 2 ] && [ $memory -eq 15 ]
	then
		export POD_TYPE_FOR_AUDIT=oc4
	else
		if [ $core -eq 4 ] && [ $memory -eq 30 ]
		then
			export POD_TYPE_FOR_AUDIT=oc5
		else
			if [ $core -eq 8 ] && [ $memory -eq 60 ]
			then
				export POD_TYPE_FOR_AUDIT=oc6
			else
				if [ $core -eq 1 ] && [ $memory -eq 15 ]
				then
					export POD_TYPE_FOR_AUDIT=oc1m
				else
					if [ $core -eq 2 ] && [ $memory -eq 30 ]
					then	
						export POD_TYPE_FOR_AUDIT=oc2m
					else
						if [ $core -eq 4 ] && [ $memory -eq 60 ]
						then 
							export POD_TYPE_FOR_AUDIT=oc3m
						else
							if [ $core -eq 8 ] && [ $memory -eq 120 ]
							then
								export POD_TYPE_FOR_AUDIT=oc4m
							else
								if [ $core -eq 16 ] && [ $memory -eq 240 ]
								then
									export POD_TYPE_FOR_AUDIT=oc5m
								fi
							fi
						fi
					fi
				fi
			fi
		fi
	fi
fi
								
							

cp /u01/data/domain/fmw/user_projects/domains/bi/config/fmwconfig/biconfig/OBIS/NQSConfig.INI .
cp /u01/data/domain/fmw/user_projects/domains/bi/bin/setStartupEnv.sh .
cp /u01/data/domain/fmw/user_projects/domains/bi/config/fmwconfig/bienv/OBIJH/obijh.properties .
cp /u01/data/domain/fmw/user_projects/domains/bi/config/fmwconfig/biconfig/OBIPS/instanceconfig.xml .

echo `hostname -f` "pod's shape is $POD_TYPE_FOR_AUDIT"
