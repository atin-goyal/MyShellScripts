#!/bin/bash
#set -x
#exec 2>/dev/null

convertTOBytes()
{
unit=`echo ${1: -1}`
size=`echo $1 | tr -dc '0-9'`

if [ $unit == "m" ]
then
bytes=`echo "$size*1024*1024"|bc -l`
else if [ $unit == "g" ]
then
bytes=`echo "$size*1024*1024*1024"|bc -l`
else
echo "ERROR: converting heap size to bytes"
fi
fi
}

if [ ! -e obijh.properties ]
then
        echo "ERROR: obijh.properties not found."
        exit
fi

tmp=`grep -o -P '(?<=Xmx).+?(?= )' obijh.properties| tr '[:upper:]' '[:lower:]'`
convertTOBytes $tmp
tmp_bytes=$bytes

convertTOBytes $JH_MAX_HEAP_SIZE
JH_MAX_HEAP_SIZE_bytes=$bytes

if [ $tmp_bytes -ne $JH_MAX_HEAP_SIZE_bytes ]
then
echo "MISMATCH:JH_MAX_HEAP_SIZE is set to $tmp. It should be set to $JH_MAX_HEAP_SIZE"
else
echo "MATCH:JH_MAX_HEAP_SIZE is correctly set to $tmp"
fi

tmp=`ps -ef|grep bi_server1 | grep -o -P '(?<=Xmx).+?(?= )' | tail -1 | tr '[:upper:]' '[:lower:]'`
convertTOBytes $tmp
tmp_bytes=$bytes

convertTOBytes $BI_SERVER1_MAX_HEAP_SIZE
BI_SERVER1_MAX_HEAP_SIZE_bytes=$bytes

if [ $tmp_bytes -ne $BI_SERVER1_MAX_HEAP_SIZE_bytes ]
then
echo "MISMATCH:BI_SERVER1_MAX_HEAP_SIZE is set to $tmp. It should be set to $BI_SERVER1_MAX_HEAP_SIZE"
else
echo "MATCH:BI_SERVER1_MAX_HEAP_SIZE is correctly set to $tmp"
fi

tmp=`ps -ef|grep bi_server1 | grep -o -P '(?<=Xms).+?(?= )' | tail -1 | tr '[:upper:]' '[:lower:]'`
convertTOBytes $tmp
tmp_bytes=$bytes

convertTOBytes $BI_SERVER1_MIN_HEAP_SIZE
BI_SERVER1_MIN_HEAP_SIZE_bytes=$bytes

if [ $tmp_bytes -ne $BI_SERVER1_MIN_HEAP_SIZE_bytes ]
then
echo "MISMATCH:BI_SERVER1_MIN_HEAP_SIZE is set to $tmp. It should be set to $BI_SERVER1_MIN_HEAP_SIZE"
else
echo "MATCH:BI_SERVER1_MIN_HEAP_SIZE is correctly set to $tmp"
fi

