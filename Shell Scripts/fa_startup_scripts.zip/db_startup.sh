#!/bin/bash
set -x
source /slot/ems2065/oracle/db/tech_st/11.2.0/ems2065_slcai763.env
/slot/ems2065/oracle/db/tech_st/11.2.0/bin/lsnrctl start ems2065

/slot/ems2065/oracle/db/tech_st/11.2.0/bin/sqlplus '/ as sysdba' <<EOF
startup
EOF
exit

