#!/bin/bash
set -x
rm -rf /slot/ems3571/appmgr/APPTOP/instance/domains/*/*/servers/*/tmp/*
rm -rf /slot/ems3571/appmgr/APPTOP/instance/domains/*/*/servers/*/data/ldap/ldapfiles/EmbeddedLDAP.lok
rm -rf /slot/ems3571/appmgr/APPTOP/instance/domains/*/*/servers/*/data/store/diagnostics/WLS_DIAGNOSTICS000000.DAT
rm -rf /slot/ems3571/appmgr/APPTOP/instance/domains/*/*/servers/*/data/store/default/_WLS_*DAT
rm -rf /slot/ems3571/appmgr/APPTOP/instance/domains/*/*/BPMJMSFileStore_auto_1/BPMJMSFILESTORE_AUTO_1000000.DAT
rm -rf /slot/ems3571/appmgr/APPTOP/instance/domains/*/*/SOAJMSFileStore_auto_1/SOAJMSFILESTORE_AUTO_1000000.DAT
rm -rf /slot/ems3571/appmgr/APPTOP/instance/domains/*/*/UMSJMSFileStore_auto_1/UMSJMSFILESTORE_AUTO_1000000.DAT

/slot/ems3571/appmgr/APPTOP/instance/CommonDomain_webtier/bin/opmnctl startall
sleep 2
/slot/ems3571/appmgr/APPTOP/instance/CommonDomain_webtier/bin/opmnctl status -l
/slot/ems3571/appmgr/APPTOP/instance/nodemanager/slcai763.us.oracle.com/startNodeManagerWrapper.sh >& ~/nm.log&
/slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/CommonDomain/bin/startWebLogic.sh >& /slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/CommonDomain/servers/AdminServer/logs/AdminServer.out &
/slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/CRMDomain/bin/startWebLogic.sh >& /slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/CRMDomain/servers/AdminServer/logs/AdminServer.out &
/slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/FinancialDomain/bin/startWebLogic.sh >&         /slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/FinancialDomain/servers/AdminServer/logs/AdminServer.out &
/slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/HCMDomain/bin/startWebLogic.sh >& /slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/HCMDomain/servers/AdminServer/logs/AdminServer.out &
/slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/BIDomain/bin/startWebLogic.sh >& /slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/BIDomain/servers/AdminServer/logs/AdminServer.out &
/slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/SCMDomain/bin/startWebLogic.sh >& /slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/SCMDomain/servers/AdminServer/logs/AdminServer.out &
/slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/ICDomain/bin/startWebLogic.sh >& /slot/ems3571/appmgr/APPTOP/instance/domains/slcai763.us.oracle.com/ICDomain/servers/AdminServer/logs/AdminServer.out &

sleep 600
cd /slot/ems3571/appmgr/APPTOP/instance/BIInstance
readlink -f tmp|xargs mkdir
cd bin
./opmnctl startall
sleep 5
./opmnctl status -l
exit

