#colmux -addr slcam838,slcam839,slcam840,slcam834 -command "-p /scratch/logs/2/*20140828*  --from 15:04-15:06 -oT  -s+m " -cols 2,3,4,5 -coltot | head -n -2
#CMD="colmux -addr slcam838,slcam839,slcam840,slcam834 -command "-p /scratch/logs/2/*20140829* --from ${2}-${3} -s+m" -cols 1,2,3,4,5,11,13,15,17 -coltot "
LOGLOC=$2
echo "Log location......$LOGLOC"
#. ~/envsetup.sh 10 10
. ~/envsetup.sh 100 100
MYHOSTS=("$COH_HOST $AGENT_HOST")
h=""
echo ${MYHOSTS}
for host in ${MYHOSTS}
        do
        h="$host,$h"
        done

echo "........all hosts are .......$h!!!!!"

DATE=$(eval ./ext-date.sh $LOGLOC)*
echo "DATE...$DATE"

CMD=$*
echo ".....$CMD"
echo "${LOGLOC}"
#echo "${LOGLOC}">${LOGLOC}/location.txt
if [ $1 == "-a" ]; then
        echo "colmux -addr $h -command \"-p ${LOGLOC}/${DATE}  -s+m\"  -cols  1,15,17 -coltot | head -n -2"
#colmux -addr $h -command "-p ${LOGLOC}/${DATE} -oT  -s+m " -cols 2,3,4,5 | head -n -2
colmux -addr $h -command "-p ${LOGLOC}/${DATE}  -s+m " -cols 1,15,17 -coltot | head -n -2
#colmux -addr $h -command "-p /u01/logs/9/*20150113*  -s+m -oT" -cols 15,17

elif [ $1 == "-d" ]; then

colmux -addr $h -command "-p ${LOGLOC}/${DATE}   -oT  -s+m " -cols 2,3,4,5,6,12,14,16,18 | head -n -2
elif [ $1 == "-m" ]; then
echo "1 cpu     2 sys     3 inter   4 ctxsw   5 Free  11 KBRead   13 KBWrit 15 KBIn  17 KBOut "
colmux -addr $h -command "-p ${LOGLOC}/${DATE} -s+m" -cols 1,2,3,4,5,11,13,15,17 | head -n -2
#colmux -addr $h -command "-p ${LOGLOC}/${DATE}  -s+m" -cols 1,2,3,4,5,11,13,15,17 | head -n -2 | r -c summary - | grep Mean | xargs | sed "s, Mean :,\,,g"
elif [ $1 == "-s" ]; then
colmux -addr $h -command "-p ${LOGLOC}/${DATE}  -s+m" -cols 1,2,3,4,5,11,13,15,17

#elif [ $1 == "-t" ]; then


# Test
colmux -addr $h -command "-p ${LOGLOC}/${DATE}  -s+m" -cols 1,2,3,4,5,11,13,15,17 -coltot  -test
fi

