LOGLOC=/u01/logs
start_time=`date`
RUN_ID=`cat sequence`
let "RUN_ID++"; echo $RUN_ID > sequence
cp sequence ../sequence
echo "Run id is.....${RUN_ID}....location is ${LOGLOC}......started at ${start_time}"
LOC=${LOGLOC}/${RUN_ID}
rcc mkdir ${LOC}
. ~/envsetup.sh 90 90
dst=`echo $COH_HOST|awk '{print $1}'`
ping $dst -i 10 -s 4000 -c 12  > ${LOC}/pingwarmpup.log 2>&1 &
./tail-appdata.sh start ${LOC} 
sleep 240
warmup_time=`date`
echo "${warmup_time}.......warmup time"
sleep 30

rcc "/u01/psr/drive/startcollectl.sh 60 ${LOC}"
rcc "sar 10 60  > ${LOC}/sar.log 2>&1 &"
rcc "vmstat 10 60  > ${LOC}/vmstat.log 2>&1 &"
rcc "top -b -d 30 -u oracle  > ${LOC}/top.log 2>&1 &"

pwd
ping $dst -i 10 -s 4000 -c 30  > ${LOC}/pingsteadystate.log 2>&1 &
sleep 300
rcc "free -m   > ${LOC}/freemem.log 2>&1 &"
rcc "ps -aef  > ${LOC}/psdata.log 2>&1 &"
sleep 300
rcc "/u01/psr/drive/kcollectl.sh 60"

rcc "pkill top"

end_time=`date`
echo "${end_time}.......end time.....RUNN ID ${RUN_ID}"
