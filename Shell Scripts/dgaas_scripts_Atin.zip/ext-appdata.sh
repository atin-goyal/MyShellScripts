sid=$1
jvmid=$2
rcc "cat ${LOC}/server.out|grep  Total, | sed 's/Total, ,,,,,,//g' | sed 's/,/ /g' | awk '{print $6 "  " $8}'|tail -n1" > log
cat log | grep ^[0-9] | awk '{print $6 $8}' > ${LOC}/appdata.log
exit
