#!/bin/bash
#set -x
Loc=$2
DOMAIN_HOME="/u01/data/domains/PSRServi_domain"

. ~/envsetup.sh 90 90
declare -A jaas
for name in $AGENT_HOST
do 
servers=`ssh $name "ls ${DOMAIN_HOME}/servers | grep -iv \"domain\|admin\""`
jaas[$name]=$servers
done

if [ $1 == "start" ]
then
for name in "${!jaas[@]}"
do 
 for server in "${jaas[$name]}"
 do
  ssh $name "tail -Fn0  ${DOMAIN_HOME}/servers/${server}/logs/${server}.out  >&  ${Loc}/${server}.out &"  
 done
done
elif [ $1 == "stop" ]
then
for name in "${!jaas[@]}"
do
 echo "$name `ssh $name "cat ${Loc}/*.out|grep  Total, | sed 's/Total, ,,,,,,//g' | sed 's/,/ /g' | awk '{print \\$6,\\$8}'|tail -n1"`" >> ${Loc}/appdata.log 
done 
fi

exit
