#!/bin/bash
set -x
No_of_tests=15
i=1
echo > Test_results.log
while [ "$i" -le "$No_of_tests" ]
do
./xcollectl.sh &
sleep 1198
seq=`cat sequence`
./x-pp.sh $seq
cat /u01/logs/${seq}/summary.log >> Test_results.log
((i=i+1))
done
exit
