#LOGLOC="/home/sbalaram/ET/extend-test/log/43"
#ls $1/*.gz | sed -n -e 1,+p | grep -o "\-[0-9]\+\-"| sed 's,-,*,g'
#ls $1/*.gz | sed -n -e 1,+p | grep -o "\-[0-9]\+" | sed -n -e 4,+p  | sed 's,-,*,g'
ls $1/*.gz | sed -n -e 1,+p | grep -o "\-[0-9]\+" | sed -n -e 2,+p  | sed 's,-,*,g'
