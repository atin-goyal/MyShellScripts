#!/bin/bash
echo "2631,2716,2717,2847,9350,9509,9668,9831" > DG_RSS.log
i=0
while [ $i -ne 60 ]
do
rss1=`ssh psrservice17-wls-19 "ps -o "rss" -p 2631 | grep -v RSS"`
rss2=`ssh psrservice17-wls-19 "ps -o "rss" -p 2716 | grep -v RSS"`
rss3=`ssh psrservice17-wls-19 "ps -o "rss" -p 2717 | grep -v RSS"`
rss4=`ssh psrservice17-wls-19 "ps -o "rss" -p 2847 | grep -v RSS"`
rss5=`ssh psrservice17-wls-20 "ps -o "rss" -p 9350 | grep -v RSS"`
rss6=`ssh psrservice17-wls-20 "ps -o "rss" -p 9509 | grep -v RSS"`
rss7=`ssh psrservice17-wls-20 "ps -o "rss" -p 9668 | grep -v RSS"`
rss8=`ssh psrservice17-wls-20 "ps -o "rss" -p 9831 | grep -v RSS"`
echo "$rss1,$rss2,$rss3,$rss4,$rss5,$rss6,$rss7,$rss8" >> DG_RSS.log
sleep 60
i=`expr $i + 1`
done
