#! /bin/bash
NODES=$1

. ~/envsetup.sh 90 90


echo "Drivers .....$AGENT_HOST"
echo "Servers......$COH_HOST"


i=0
for host in $AGENT_HOST
do
names[$i]=$host
cs[$i]=`ssh $host cat /u01/logs/${1}/vmstat.log |grep ^\ [0-9]|awk '{print $4+$5}'|tail -n +2|awk '{ sum += $1 } END { if (NR > 0) print sum / NR }'`
((i=i+1))
done

printf '%s,' "${names[@]}" > jaas_cs_${1}.log
printf '\n' >> jaas_cs_${1}.log
printf '%s,' "${cs[@]}" >> jaas_cs_${1}.log

i=0
for host in $COH_HOST
do
names1[$i]=$host
cs1[$i]=`ssh $host cat /u01/logs/${1}/vmstat.log |grep ^\ [0-9]|awk '{print $4+$5}'|tail -n +2|awk '{ sum += $1 } END { if (NR > 0) print sum / NR }'`
((i=i+1))
done

printf '%s,' "${names1[@]}" > dgaas_cs_${1}.log
printf '\n' >> dgaas_cs_${1}.log
printf '%s,' "${cs1[@]}" >> dgaas_cs_${1}.log
exit
