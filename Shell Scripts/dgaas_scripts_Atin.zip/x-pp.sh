LOGLOC=/u01/logs/$1

echo "" > ${LOGLOC}/appdata.log
rcc "pkill tail"
./tail-appdata.sh stop ${LOGLOC}
cat ${LOGLOC}/appdata.log | grep [0-9]$ | awk '{c2+=$2;c3+=$3;}END{print c2,c3/NR}'  >  ${LOGLOC}/appsummary.log

echo "" > ${LOGLOC}/sysmet.log
./ext-stat.sh -a $LOGLOC > $LOGLOC/sysmet.log

. ~/envsetup.sh 90 90
no_of_servers=`echo $HOSTS|wc -w`
cat  ${LOGLOC}/sysmet.log | tail -n -9 | awk '{
j='$no_of_servers';
for (i = 1; i <= NF-3; i++) {
c[i]=c[i]+$i;
if (i==j){
i++;
j=i+'$no_of_servers';
continue;
}}} 
END { 
j='$no_of_servers';
for (x = 1; x < i; x++){ 
printf ("%s ",c[x]/NR);
if (x==j){
x++;
j=x+'$no_of_servers';
continue;
}}}' 2>&1 > $LOGLOC/syssummary.log

cat ${LOGLOC}/pingsteadystate.log | grep rtt | cut -d'=' -f2  2>&1 | sed "s,/, ,g" | sed "s,ms,,g" >> ${LOGLOC}/syssummary.log
cat ${LOGLOC}/*summary.log | xargs 2>&1 | tee ${LOGLOC}/summary.log

rcc free -g > ${LOGLOC}/memoryinfo.txt
rcc cat /proc/cpuinfo > ${LOGLOC}/cpuinfo.txt
exit
